FTGL Version 2.0 Demo

This demo demonstrates the different rendering styles available with FTGL.
Press <spacebar> to change the font rendering style.
Press <enter> to enable edit mode.

When compiling you will need to check the paths to the font files as they are
hard coded. See #define FONT_FILE and #define FONT_INFO in FTGLDemo.c


Please contact me if you have any suggestions, feature requests, or problems.

Henry Maddocks
henryj@paradise.net.nz
http://homepages.paradise.net.nz/henryj/
