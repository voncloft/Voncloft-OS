FTGL Version 2.02

Unit Tests

To run the unit tests the following fonts should be sourced and placed in this
directory.

raghu.ttf is available from http://rohini.ncst.ernet.in/indix/download/font/
HPGCalc.pfb & HPGCalc.afm are available from
http://www.geocities.com/jking_ok/font.html
LucidaSansRegular.ttf and Thoburi.ttf are part of the Java 2 SDK from IBM
times.ttf and arial.ttf are windows system fonts.

Please contact me if you have any suggestions, feature requests, or problems.


Henry Maddocks
henryj@paradise.net.nz
http://homepages.paradise.net.nz/henryj/
