FTGL Version 2.0

Unit Tests.

The unit tests in this directory are built using the cppunit unit testing
framework. cppunit is available from...
cppunit.sf.net

Refer to that website for build and usage instructions.

Check the 'Fontdefs.h' file or the README.txt in the font_pack directory
for the list of fonts required for the tests and where to get them from.

The file 'demo.cpp' is for visually checking the library. It displays a
test string of characters in each font 'type'.

Please contact me if you have any suggestions, feature requests, or problems.


Henry Maddocks
henryj@paradise.net.nz
http://homepages.paradise.net.nz/henryj/
