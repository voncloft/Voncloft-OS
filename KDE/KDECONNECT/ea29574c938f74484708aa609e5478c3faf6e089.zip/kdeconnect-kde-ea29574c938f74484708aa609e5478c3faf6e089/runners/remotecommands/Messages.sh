#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/plasma_runner_kdeconnect_remotecommands.pot
